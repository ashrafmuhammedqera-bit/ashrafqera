import type { CVTemplate } from "@shared/schema";

export const CV_TEMPLATES: CVTemplate[] = [
  {
    id: "accountant",
    name: "Professional Accountant",
    description: "Clean and professional design perfect for accounting and finance roles",
    category: "professional",
    thumbnail: "/templates/accountant.png",
  },
  {
    id: "hr-generalist",
    name: "HR Generalist",
    description: "Modern layout ideal for human resources and management positions",
    category: "modern",
    thumbnail: "/templates/hr-generalist.png",
  },
  {
    id: "executive",
    name: "Executive Leader",
    description: "Bold design for senior leadership and executive positions",
    category: "professional",
    thumbnail: "/templates/executive.png",
  },
  {
    id: "office-manager",
    name: "Office Manager",
    description: "Structured format great for administrative and operations roles",
    category: "classic",
    thumbnail: "/templates/office-manager.png",
  },
  {
    id: "creative",
    name: "Creative Professional",
    description: "Eye-catching design for designers, artists, and creative fields",
    category: "creative",
    thumbnail: "/templates/creative.png",
  },
];
