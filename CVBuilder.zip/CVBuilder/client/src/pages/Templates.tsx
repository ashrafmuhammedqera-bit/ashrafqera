import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FileText, ArrowRight } from "lucide-react";
import { CV_TEMPLATES } from "@/data/templates";
import { cn } from "@/lib/utils";

export default function Templates() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Professional CV Templates</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose from our collection of expertly designed templates, optimized for ATS and designed to impress.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {CV_TEMPLATES.map((template) => (
              <Card
                key={template.id}
                className="overflow-hidden hover-elevate transition-all duration-300"
                data-testid={`template-card-${template.id}`}
              >
                <div className="aspect-[3/4] bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center p-8">
                  <div className="text-center">
                    <FileText className="w-24 h-24 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-sm font-medium text-muted-foreground">{template.name}</p>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-semibold mb-1">{template.name}</h3>
                      <span className={cn(
                        "inline-block px-2 py-1 text-xs rounded-full",
                        "bg-primary/10 text-primary font-medium"
                      )}>
                        {template.category}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setLocation("/builder")}
                    data-testid={`button-use-${template.id}`}
                  >
                    Use This Template
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button
              size="lg"
              onClick={() => setLocation("/builder")}
              className="px-8"
              data-testid="button-start-building"
            >
              Start Building Your CV
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
