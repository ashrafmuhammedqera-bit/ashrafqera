import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { ProgressSteps } from "@/components/ProgressSteps";
import { PersonalInfoStep } from "@/components/builder/PersonalInfoStep";
import { ExperienceStep } from "@/components/builder/ExperienceStep";
import { EducationStep } from "@/components/builder/EducationStep";
import { SkillsStep } from "@/components/builder/SkillsStep";
import { TemplateStep } from "@/components/builder/TemplateStep";
import { PreviewStep } from "@/components/builder/PreviewStep";
import type { CVData } from "@shared/schema";

const steps = [
  { id: 1, name: "Personal Info", shortName: "Info" },
  { id: 2, name: "Experience", shortName: "Work" },
  { id: 3, name: "Education", shortName: "School" },
  { id: 4, name: "Skills", shortName: "Skills" },
  { id: 5, name: "Template", shortName: "Style" },
  { id: 6, name: "Preview", shortName: "Done" },
];

const initialCVData: Partial<CVData> = {
  personalInfo: {
    fullName: "",
    title: "",
    email: "",
    phone: "",
    website: "",
    address: "",
  },
  summary: "",
  experience: [],
  education: [],
  skills: [],
  references: "",
  activities: "",
};

export default function CVBuilder() {
  const [currentStep, setCurrentStep] = useState(1);
  const [cvData, setCVData] = useState<Partial<CVData>>(initialCVData);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");

  useEffect(() => {
    const saved = localStorage.getItem("cv-draft");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setCVData(parsed.cvData || initialCVData);
        setSelectedTemplate(parsed.templateId || "");
        setCurrentStep(parsed.step || 1);
      } catch (e) {
        console.error("Failed to load draft:", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("cv-draft", JSON.stringify({
      cvData,
      templateId: selectedTemplate,
      step: currentStep,
    }));
  }, [cvData, selectedTemplate, currentStep]);

  const updateCVData = (data: Partial<CVData>) => {
    setCVData((prev) => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    setCurrentStep((prev) => Math.min(prev + 1, steps.length));
  };

  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ProgressSteps currentStep={currentStep} steps={steps} />
        </div>
      </div>

      <main className="flex-1 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {currentStep === 1 && (
            <PersonalInfoStep
              data={cvData}
              onUpdate={updateCVData}
              onNext={nextStep}
            />
          )}
          {currentStep === 2 && (
            <ExperienceStep
              data={cvData}
              onUpdate={updateCVData}
              onNext={nextStep}
              onPrev={prevStep}
            />
          )}
          {currentStep === 3 && (
            <EducationStep
              data={cvData}
              onUpdate={updateCVData}
              onNext={nextStep}
              onPrev={prevStep}
            />
          )}
          {currentStep === 4 && (
            <SkillsStep
              data={cvData}
              onUpdate={updateCVData}
              onNext={nextStep}
              onPrev={prevStep}
            />
          )}
          {currentStep === 5 && (
            <TemplateStep
              selectedTemplate={selectedTemplate}
              onSelectTemplate={setSelectedTemplate}
              onNext={nextStep}
              onPrev={prevStep}
            />
          )}
          {currentStep === 6 && (
            <PreviewStep
              cvData={cvData as CVData}
              templateId={selectedTemplate}
              onPrev={prevStep}
            />
          )}
        </div>
      </main>
    </div>
  );
}
