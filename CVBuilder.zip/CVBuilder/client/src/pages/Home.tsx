import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FileText, Sparkles, Download, CheckCircle2, Users, Shield, Zap } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  const features = [
    {
      icon: Sparkles,
      title: "Smart Questions",
      description: "Answer guided questions to build your CV. No formatting hassle, just focus on your achievements."
    },
    {
      icon: FileText,
      title: "Professional Templates",
      description: "Choose from expertly designed templates that make your CV stand out to employers."
    },
    {
      icon: Download,
      title: "Multiple Formats",
      description: "Download your CV in PDF or DOCX format, ready to send to employers instantly."
    },
    {
      icon: Shield,
      title: "ATS-Friendly",
      description: "All templates are optimized for Applicant Tracking Systems to ensure your CV gets seen."
    },
    {
      icon: Zap,
      title: "Build in Minutes",
      description: "Complete your professional CV in under 10 minutes with our streamlined process."
    },
    {
      icon: Users,
      title: "Trusted by Thousands",
      description: "Join 10,000+ professionals who've landed their dream jobs with our CV builder."
    }
  ];

  const steps = [
    {
      number: "01",
      title: "Answer Questions",
      description: "Fill out a simple form with your experience, education, and skills."
    },
    {
      number: "02",
      title: "Choose Template",
      description: "Select from professionally designed CV templates that suit your style."
    },
    {
      number: "03",
      title: "Download CV",
      description: "Get your polished CV in PDF or DOCX format, ready to send."
    }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                    Build Your Professional CV in{" "}
                    <span className="text-primary">Minutes</span>
                  </h1>
                  <p className="text-xl text-muted-foreground leading-relaxed">
                    Answer smart questions, choose your template, and download your perfect CV. 
                    No design skills needed.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    onClick={() => setLocation("/builder")}
                    className="text-base px-8 py-6 h-auto"
                    data-testid="button-get-started"
                  >
                    <FileText className="w-5 h-5 mr-2" />
                    Get Started Free
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => setLocation("/templates")}
                    className="text-base px-8 py-6 h-auto"
                    data-testid="button-view-templates"
                  >
                    View Templates
                  </Button>
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-chart-2" />
                  <span>Join 10,000+ professionals</span>
                </div>
              </div>

              <div className="relative">
                <div className="aspect-[4/3] bg-gradient-to-br from-primary/10 to-primary/5 rounded-3xl shadow-2xl flex items-center justify-center border border-primary/20">
                  <div className="text-center p-8">
                    <FileText className="w-32 h-32 mx-auto text-primary mb-4" />
                    <p className="text-lg font-semibold text-foreground">Your Perfect CV Awaits</p>
                    <p className="text-sm text-muted-foreground mt-2">Professional. Polished. Perfect.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Three simple steps to your professional CV
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {steps.map((step, index) => (
                <Card key={index} className="p-8 text-center hover-elevate transition-shadow" data-testid={`card-step-${index + 1}`}>
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary text-2xl font-bold mb-6">
                    {step.number}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Qera's Smart Assistant?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Everything you need to create a standout CV
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="p-6 hover-elevate transition-shadow" data-testid={`card-feature-${index + 1}`}>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Build Your Perfect CV?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who've successfully landed their dream jobs with Qera's Smart Assistant.
            </p>
            <Button
              size="lg"
              onClick={() => setLocation("/builder")}
              className="text-base px-8 py-6 h-auto"
              data-testid="button-cta-start"
            >
              <FileText className="w-5 h-5 mr-2" />
              Start Building Now - It's Free
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
