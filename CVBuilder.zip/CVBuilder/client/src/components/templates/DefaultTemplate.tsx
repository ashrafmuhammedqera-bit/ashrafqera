import type { CVData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe } from "lucide-react";

interface TemplateProps {
  cvData: CVData;
}

export function DefaultTemplate({ cvData }: TemplateProps) {
  const { personalInfo, summary, experience, education, skills, references, activities } = cvData;

  return (
    <div className="text-sm text-gray-900">
      <div className="text-center mb-6 pb-4 border-b-2 border-gray-900">
        <h1 className="text-3xl font-bold mb-1">{personalInfo.fullName}</h1>
        <p className="text-lg text-gray-700 mb-3">{personalInfo.title}</p>
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm">
          {personalInfo.email && (
            <div className="flex items-center gap-1">
              <Mail className="w-3 h-3" />
              <span>{personalInfo.email}</span>
            </div>
          )}
          {personalInfo.phone && (
            <div className="flex items-center gap-1">
              <Phone className="w-3 h-3" />
              <span>{personalInfo.phone}</span>
            </div>
          )}
          {personalInfo.website && (
            <div className="flex items-center gap-1">
              <Globe className="w-3 h-3" />
              <span>{personalInfo.website}</span>
            </div>
          )}
          {personalInfo.address && (
            <div className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>{personalInfo.address}</span>
            </div>
          )}
        </div>
      </div>

      {summary && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">Summary</h2>
          <p className="text-gray-700 leading-relaxed">{summary}</p>
        </div>
      )}

      {experience && experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3 text-gray-900 uppercase border-b border-gray-300">Experience</h2>
          <div className="space-y-4">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <h3 className="font-bold text-gray-900">{exp.title}</h3>
                    <p className="text-gray-700">{exp.company}{exp.location && ` | ${exp.location}`}</p>
                  </div>
                  <div className="text-right text-sm text-gray-600">
                    {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                  </div>
                </div>
                {exp.description && (
                  <p className="text-gray-700 leading-relaxed mt-1">{exp.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {education && education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3 text-gray-900 uppercase border-b border-gray-300">Education</h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <h3 className="font-bold text-gray-900">{edu.degree}</h3>
                    <p className="text-gray-700">{edu.school}{edu.location && ` | ${edu.location}`}</p>
                  </div>
                  {edu.graduationDate && (
                    <div className="text-sm text-gray-600">{edu.graduationDate}</div>
                  )}
                </div>
                {edu.gpa && (
                  <p className="text-sm text-gray-700">GPA: {edu.gpa}</p>
                )}
                {edu.coursework && (
                  <p className="text-sm text-gray-700">Coursework: {edu.coursework}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {skills && skills.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">Skills</h2>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <span key={index} className="text-gray-700">
                {skill}{index < skills.length - 1 ? " •" : ""}
              </span>
            ))}
          </div>
        </div>
      )}

      {activities && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">Activities & Interests</h2>
          <p className="text-gray-700 leading-relaxed">{activities}</p>
        </div>
      )}

      {references && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">References</h2>
          <p className="text-gray-700 leading-relaxed">{references}</p>
        </div>
      )}
    </div>
  );
}
