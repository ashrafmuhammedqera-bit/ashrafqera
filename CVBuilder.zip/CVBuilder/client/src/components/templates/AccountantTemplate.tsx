import type { CVData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe } from "lucide-react";

interface TemplateProps {
  cvData: CVData;
}

export function AccountantTemplate({ cvData }: TemplateProps) {
  const { personalInfo, summary, experience, education, skills, references, activities } = cvData;

  return (
    <div className="text-sm text-gray-900">
      <div className="text-center mb-6 pb-4 border-b-2 border-gray-900">
        <h1 className="text-3xl font-bold mb-1">{personalInfo.fullName}</h1>
        <p className="text-lg text-gray-700 mb-3">{personalInfo.title}</p>
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm">
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.website && <span>{personalInfo.website}</span>}
        </div>
      </div>

      {summary && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">Background</h2>
          <p className="text-gray-700 leading-relaxed">{summary}</p>
        </div>
      )}

      {education && education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3 text-gray-900 uppercase border-b border-gray-300">Education</h2>
          {education.map((edu) => (
            <div key={edu.id} className="mb-3">
              <p className="font-bold text-gray-900">{edu.degree}</p>
              <p className="text-gray-700">{edu.school}, {edu.graduationDate}</p>
              {edu.coursework && <p className="text-sm text-gray-700 mt-1">{edu.coursework}</p>}
              {edu.gpa && <p className="text-sm text-gray-700">GPA: {edu.gpa}</p>}
            </div>
          ))}
        </div>
      )}

      {experience && experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3 text-gray-900 uppercase border-b border-gray-300">Experience</h2>
          {experience.map((exp) => (
            <div key={exp.id} className="mb-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-gray-900">{exp.company} | {exp.title}</p>
                  <p className="text-gray-700">{exp.location}</p>
                </div>
                <p className="text-sm text-gray-600">{exp.startDate} - {exp.current ? "present" : exp.endDate}</p>
              </div>
              {exp.description && <p className="text-gray-700 leading-relaxed mt-1">{exp.description}</p>}
            </div>
          ))}
        </div>
      )}

      {skills && skills.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 text-gray-900 uppercase border-b border-gray-300">Skills</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            {skills.map((skill, index) => (
              <p key={index} className="text-gray-700">{skill}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
