import type { CVData } from "@shared/schema";

interface TemplateProps {
  cvData: CVData;
}

export function ModernTemplate({ cvData }: TemplateProps) {
  const { personalInfo, summary, experience, education, skills } = cvData;

  return (
    <div className="text-sm text-gray-900">
      <div className="bg-blue-600 text-white p-6 -mx-8 -mt-8 mb-6">
        <h1 className="text-4xl font-bold mb-2">{personalInfo.fullName}</h1>
        <p className="text-xl mb-3">{personalInfo.title}</p>
        <div className="flex flex-wrap gap-4 text-sm">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.address && <span>{personalInfo.address}</span>}
        </div>
      </div>

      {summary && (
        <div className="mb-6 p-4 bg-gray-50 rounded">
          <h2 className="text-lg font-bold mb-2 text-blue-600">PROFESSIONAL SUMMARY</h2>
          <p className="text-gray-700 leading-relaxed">{summary}</p>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2">
          {experience && experience.length > 0 && (
            <div className="mb-6">
              <h2 className="text-lg font-bold mb-3 text-blue-600 border-b-2 border-blue-600 pb-1">EXPERIENCE</h2>
              {experience.map((exp) => (
                <div key={exp.id} className="mb-4">
                  <p className="font-bold text-lg text-gray-900">{exp.title}</p>
                  <p className="text-blue-600 font-medium">{exp.company} | {exp.location}</p>
                  <p className="text-sm text-gray-600 italic mb-1">
                    {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                  </p>
                  {exp.description && <p className="text-gray-700 leading-relaxed">{exp.description}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="col-span-1">
          {education && education.length > 0 && (
            <div className="mb-6">
              <h2 className="text-base font-bold mb-2 text-blue-600 border-b border-blue-600 pb-1">EDUCATION</h2>
              {education.map((edu) => (
                <div key={edu.id} className="mb-3">
                  <p className="font-bold text-sm">{edu.degree}</p>
                  <p className="text-xs text-gray-700">{edu.school}</p>
                  <p className="text-xs text-gray-600">{edu.graduationDate}</p>
                  {edu.gpa && <p className="text-xs text-gray-600">GPA: {edu.gpa}</p>}
                </div>
              ))}
            </div>
          )}

          {skills && skills.length > 0 && (
            <div className="mb-6">
              <h2 className="text-base font-bold mb-2 text-blue-600 border-b border-blue-600 pb-1">SKILLS</h2>
              <ul className="space-y-1">
                {skills.map((skill, index) => (
                  <li key={index} className="text-xs text-gray-700">• {skill}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
