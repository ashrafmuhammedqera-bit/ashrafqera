import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, FileText, Check } from "lucide-react";
import { CV_TEMPLATES } from "@/data/templates";
import { cn } from "@/lib/utils";

interface TemplateStepProps {
  selectedTemplate: string;
  onSelectTemplate: (templateId: string) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function TemplateStep({ selectedTemplate, onSelectTemplate, onNext, onPrev }: TemplateStepProps) {
  const [filter, setFilter] = useState<string>("all");

  const filteredTemplates = filter === "all" 
    ? CV_TEMPLATES 
    : CV_TEMPLATES.filter(t => t.category === filter);

  const handleNext = () => {
    if (selectedTemplate) {
      onNext();
    }
  };

  return (
    <Card className="p-8" data-testid="card-templates">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Choose Your Template</h2>
        <p className="text-muted-foreground">Select a professional design that suits your style</p>
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        {["all", "professional", "modern", "classic", "creative"].map((category) => (
          <Button
            key={category}
            variant={filter === category ? "default" : "outline"}
            onClick={() => setFilter(category)}
            size="sm"
            data-testid={`button-filter-${category}`}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {filteredTemplates.map((template) => (
          <div
            key={template.id}
            onClick={() => onSelectTemplate(template.id)}
            className={cn(
              "relative cursor-pointer rounded-lg border-2 transition-all duration-300 overflow-hidden group",
              "hover-elevate active-elevate-2",
              selectedTemplate === template.id
                ? "border-primary ring-4 ring-primary/20 scale-[1.02]"
                : "border-border hover:border-primary/50"
            )}
            data-testid={`template-${template.id}`}
          >
            <div className="aspect-[3/4] bg-gradient-to-br from-muted/50 to-muted flex items-center justify-center p-8">
              <div className="text-center">
                <FileText className="w-20 h-20 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm font-medium text-muted-foreground">{template.name}</p>
              </div>
            </div>

            <div className="p-4 bg-card">
              <h3 className="font-semibold mb-1 flex items-center justify-between">
                {template.name}
                {selectedTemplate === template.id && (
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
              </h3>
              <p className="text-sm text-muted-foreground">{template.description}</p>
            </div>
          </div>
        ))}
      </div>

      {!selectedTemplate && (
        <p className="text-sm text-muted-foreground mb-4 text-center">
          Please select a template to continue
        </p>
      )}

      <div className="flex justify-between pt-4">
        <Button type="button" variant="outline" onClick={onPrev} size="lg" data-testid="button-prev">
          <ArrowLeft className="mr-2 w-5 h-5" />
          Back
        </Button>
        <Button
          onClick={handleNext}
          size="lg"
          disabled={!selectedTemplate}
          data-testid="button-next"
        >
          Next Step
          <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </Card>
  );
}
