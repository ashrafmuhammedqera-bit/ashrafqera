import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, ArrowRight, Plus, Trash2, Briefcase } from "lucide-react";
import type { CVData } from "@shared/schema";
import { nanoid } from "nanoid";

const experienceFormSchema = z.object({
  experience: z.array(z.object({
    id: z.string(),
    title: z.string().min(1, "Job title is required"),
    company: z.string().min(1, "Company name is required"),
    location: z.string().optional(),
    startDate: z.string().min(1, "Start date is required"),
    endDate: z.string().optional(),
    current: z.boolean().optional(),
    description: z.string().optional(),
  })).min(1, "At least one work experience is required"),
});

interface ExperienceStepProps {
  data: Partial<CVData>;
  onUpdate: (data: Partial<CVData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function ExperienceStep({ data, onUpdate, onNext, onPrev }: ExperienceStepProps) {
  const form = useForm<z.infer<typeof experienceFormSchema>>({
    resolver: zodResolver(experienceFormSchema),
    defaultValues: {
      experience: data.experience && data.experience.length > 0 ? data.experience : [{
        id: nanoid(),
        title: "",
        company: "",
        location: "",
        startDate: "",
        endDate: "",
        current: false,
        description: "",
      }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "experience",
  });

  const onSubmit = (values: z.infer<typeof experienceFormSchema>) => {
    onUpdate(values);
    onNext();
  };

  return (
    <Card className="p-8" data-testid="card-experience">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Work Experience</h2>
        <p className="text-muted-foreground">Add your professional experience</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {fields.map((field, index) => (
            <div key={field.id} className="relative p-6 border border-border rounded-lg bg-card space-y-4">
              {fields.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(index)}
                  className="absolute top-4 right-4"
                  data-testid={`button-remove-experience-${index}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}

              <div className="flex items-center gap-2 mb-4">
                <Briefcase className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">Experience {index + 1}</h3>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name={`experience.${index}.title`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Title *</FormLabel>
                      <FormControl>
                        <Input placeholder="Software Engineer" {...field} data-testid={`input-job-title-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name={`experience.${index}.company`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company *</FormLabel>
                      <FormControl>
                        <Input placeholder="Tech Corp" {...field} data-testid={`input-company-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name={`experience.${index}.location`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="San Francisco, CA" {...field} data-testid={`input-location-${index}`} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name={`experience.${index}.startDate`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date *</FormLabel>
                      <FormControl>
                        <Input placeholder="Jan 2020" {...field} data-testid={`input-start-date-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name={`experience.${index}.endDate`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Dec 2023"
                          {...field}
                          disabled={form.watch(`experience.${index}.current`)}
                          data-testid={`input-end-date-${index}`}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name={`experience.${index}.current`}
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid={`checkbox-current-${index}`}
                      />
                    </FormControl>
                    <FormLabel className="font-normal cursor-pointer">I currently work here</FormLabel>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`experience.${index}.description`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe your responsibilities and achievements..."
                        rows={4}
                        {...field}
                        data-testid={`input-description-${index}`}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          ))}

          <Button
            type="button"
            variant="outline"
            onClick={() => append({
              id: nanoid(),
              title: "",
              company: "",
              location: "",
              startDate: "",
              endDate: "",
              current: false,
              description: "",
            })}
            className="w-full"
            data-testid="button-add-experience"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Another Experience
          </Button>

          <div className="flex justify-between pt-4">
            <Button type="button" variant="outline" onClick={onPrev} size="lg" data-testid="button-prev">
              <ArrowLeft className="mr-2 w-5 h-5" />
              Back
            </Button>
            <Button type="submit" size="lg" data-testid="button-next">
              Next Step
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}
