import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Download, FileText, Loader2 } from "lucide-react";
import type { CVData } from "@shared/schema";
import { CV_TEMPLATES } from "@/data/templates";
import { CVPreview } from "@/components/CVPreview";
import { useToast } from "@/hooks/use-toast";

interface PreviewStepProps {
  cvData: CVData;
  templateId: string;
  onPrev: () => void;
}

export function PreviewStep({ cvData, templateId, onPrev }: PreviewStepProps) {
  const { toast } = useToast();
  const template = CV_TEMPLATES.find(t => t.id === templateId);
  const [isDownloadingPDF, setIsDownloadingPDF] = useState(false);
  const [isDownloadingDOCX, setIsDownloadingDOCX] = useState(false);

  const handleDownloadPDF = async () => {
    try {
      setIsDownloadingPDF(true);
      toast({
        title: "Preparing PDF...",
        description: "Your CV will be ready shortly.",
      });

      const response = await fetch("/api/cvs/generate-pdf", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cvData, templateId }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate PDF");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `cv-${cvData.personalInfo.fullName.replace(/\s+/g, "-")}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Success!",
        description: "Your CV has been downloaded as PDF.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDownloadingPDF(false);
    }
  };

  const handleDownloadDOCX = async () => {
    try {
      setIsDownloadingDOCX(true);
      toast({
        title: "Preparing DOCX...",
        description: "Your CV will be ready shortly.",
      });

      const response = await fetch("/api/cvs/generate-docx", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cvData, templateId }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate DOCX");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `cv-${cvData.personalInfo.fullName.replace(/\s+/g, "-")}.docx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Success!",
        description: "Your CV has been downloaded as DOCX.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate DOCX. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDownloadingDOCX(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-8" data-testid="card-preview">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Preview & Download</h2>
          <p className="text-muted-foreground">
            Your CV is ready! Review it and download in your preferred format.
          </p>
        </div>

        <div className="flex items-center gap-4 p-4 bg-primary/5 border border-primary/20 rounded-lg mb-6">
          <FileText className="w-8 h-8 text-primary" />
          <div className="flex-1">
            <p className="font-semibold">Template: {template?.name}</p>
            <p className="text-sm text-muted-foreground">{template?.description}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-8">
          <Button
            onClick={handleDownloadPDF}
            size="lg"
            className="h-auto py-4"
            disabled={isDownloadingPDF}
            data-testid="button-download-pdf"
          >
            {isDownloadingPDF ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Download className="w-5 h-5 mr-2" />
                Download as PDF
              </>
            )}
          </Button>
          <Button
            onClick={handleDownloadDOCX}
            size="lg"
            variant="outline"
            className="h-auto py-4"
            disabled={isDownloadingDOCX}
            data-testid="button-download-docx"
          >
            {isDownloadingDOCX ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Download className="w-5 h-5 mr-2" />
                Download as DOCX
              </>
            )}
          </Button>
        </div>
      </Card>

      <Card className="p-8 bg-muted/30">
        <h3 className="text-xl font-semibold mb-4">CV Preview</h3>
        <div className="bg-white rounded-lg shadow-2xl p-8 max-w-3xl mx-auto">
          <CVPreview cvData={cvData} templateId={templateId} />
        </div>
      </Card>

      <div className="flex justify-start">
        <Button variant="outline" onClick={onPrev} size="lg" data-testid="button-prev">
          <ArrowLeft className="mr-2 w-5 h-5" />
          Back
        </Button>
      </div>
    </div>
  );
}
