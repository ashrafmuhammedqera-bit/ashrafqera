import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, ArrowRight, Plus, X, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { CVData } from "@shared/schema";
import { useState } from "react";

const skillsFormSchema = z.object({
  skills: z.array(z.string()).min(1, "At least one skill is required"),
  references: z.string().optional(),
  activities: z.string().optional(),
});

interface SkillsStepProps {
  data: Partial<CVData>;
  onUpdate: (data: Partial<CVData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function SkillsStep({ data, onUpdate, onNext, onPrev }: SkillsStepProps) {
  const [skillInput, setSkillInput] = useState("");
  
  const form = useForm<z.infer<typeof skillsFormSchema>>({
    resolver: zodResolver(skillsFormSchema),
    defaultValues: {
      skills: data.skills || [],
      references: data.references || "",
      activities: data.activities || "",
    },
  });

  const skills = form.watch("skills");

  const addSkill = () => {
    if (skillInput.trim()) {
      const currentSkills = form.getValues("skills");
      form.setValue("skills", [...currentSkills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (index: number) => {
    const currentSkills = form.getValues("skills");
    form.setValue("skills", currentSkills.filter((_, i) => i !== index));
  };

  const onSubmit = (values: z.infer<typeof skillsFormSchema>) => {
    onUpdate(values);
    onNext();
  };

  return (
    <Card className="p-8" data-testid="card-skills">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Skills & Additional Information</h2>
        <p className="text-muted-foreground">Highlight your key skills and other relevant details</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-4">
            <FormLabel>Skills *</FormLabel>
            <div className="flex gap-2">
              <Input
                placeholder="e.g., JavaScript, Project Management, Communication"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addSkill();
                  }
                }}
                data-testid="input-skill"
              />
              <Button
                type="button"
                onClick={addSkill}
                variant="outline"
                data-testid="button-add-skill"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add
              </Button>
            </div>

            {skills.length > 0 && (
              <div className="flex flex-wrap gap-2 p-4 border border-border rounded-lg bg-muted/30">
                {skills.map((skill, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="pl-3 pr-2 py-1.5 text-sm flex items-center gap-2"
                    data-testid={`badge-skill-${index}`}
                  >
                    <Target className="w-3 h-3" />
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(index)}
                      className="hover-elevate active-elevate-2 rounded-full p-0.5"
                      data-testid={`button-remove-skill-${index}`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {form.formState.errors.skills && (
              <p className="text-sm text-destructive">{form.formState.errors.skills.message}</p>
            )}
          </div>

          <FormField
            control={form.control}
            name="references"
            render={({ field }) => (
              <FormItem>
                <FormLabel>References (Optional)</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Available upon request or list your references..."
                    rows={3}
                    {...field}
                    data-testid="input-references"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="activities"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Activities & Interests (Optional)</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Hobbies, volunteer work, professional organizations..."
                    rows={3}
                    {...field}
                    data-testid="input-activities"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-between pt-4">
            <Button type="button" variant="outline" onClick={onPrev} size="lg" data-testid="button-prev">
              <ArrowLeft className="mr-2 w-5 h-5" />
              Back
            </Button>
            <Button type="submit" size="lg" data-testid="button-next">
              Next Step
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}
