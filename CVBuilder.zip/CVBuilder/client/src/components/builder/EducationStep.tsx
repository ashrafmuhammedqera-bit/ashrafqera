import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft, ArrowRight, Plus, Trash2, GraduationCap } from "lucide-react";
import type { CVData } from "@shared/schema";
import { nanoid } from "nanoid";

const educationFormSchema = z.object({
  education: z.array(z.object({
    id: z.string(),
    degree: z.string().min(1, "Degree is required"),
    school: z.string().min(1, "School name is required"),
    location: z.string().optional(),
    graduationDate: z.string().optional(),
    gpa: z.string().optional(),
    coursework: z.string().optional(),
  })).min(1, "At least one education entry is required"),
});

interface EducationStepProps {
  data: Partial<CVData>;
  onUpdate: (data: Partial<CVData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function EducationStep({ data, onUpdate, onNext, onPrev }: EducationStepProps) {
  const form = useForm<z.infer<typeof educationFormSchema>>({
    resolver: zodResolver(educationFormSchema),
    defaultValues: {
      education: data.education && data.education.length > 0 ? data.education : [{
        id: nanoid(),
        degree: "",
        school: "",
        location: "",
        graduationDate: "",
        gpa: "",
        coursework: "",
      }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "education",
  });

  const onSubmit = (values: z.infer<typeof educationFormSchema>) => {
    onUpdate(values);
    onNext();
  };

  return (
    <Card className="p-8" data-testid="card-education">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Education</h2>
        <p className="text-muted-foreground">Add your educational background</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {fields.map((field, index) => (
            <div key={field.id} className="relative p-6 border border-border rounded-lg bg-card space-y-4">
              {fields.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(index)}
                  className="absolute top-4 right-4"
                  data-testid={`button-remove-education-${index}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}

              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">Education {index + 1}</h3>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name={`education.${index}.degree`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Degree *</FormLabel>
                      <FormControl>
                        <Input placeholder="Bachelor of Science in Computer Science" {...field} data-testid={`input-degree-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name={`education.${index}.school`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>School *</FormLabel>
                      <FormControl>
                        <Input placeholder="University Name" {...field} data-testid={`input-school-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name={`education.${index}.location`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="City, State" {...field} data-testid={`input-edu-location-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name={`education.${index}.graduationDate`}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Graduation Date</FormLabel>
                      <FormControl>
                        <Input placeholder="May 2023" {...field} data-testid={`input-graduation-${index}`} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name={`education.${index}.gpa`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>GPA (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="3.8" {...field} data-testid={`input-gpa-${index}`} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`education.${index}.coursework`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Relevant Coursework (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Data Structures, Algorithms, Machine Learning..."
                        rows={3}
                        {...field}
                        data-testid={`input-coursework-${index}`}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          ))}

          <Button
            type="button"
            variant="outline"
            onClick={() => append({
              id: nanoid(),
              degree: "",
              school: "",
              location: "",
              graduationDate: "",
              gpa: "",
              coursework: "",
            })}
            className="w-full"
            data-testid="button-add-education"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Another Education
          </Button>

          <div className="flex justify-between pt-4">
            <Button type="button" variant="outline" onClick={onPrev} size="lg" data-testid="button-prev">
              <ArrowLeft className="mr-2 w-5 h-5" />
              Back
            </Button>
            <Button type="submit" size="lg" data-testid="button-next">
              Next Step
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}
