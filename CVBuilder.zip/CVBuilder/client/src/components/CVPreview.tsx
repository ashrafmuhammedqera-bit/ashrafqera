import type { CVData } from "@shared/schema";
import { AccountantTemplate } from "./templates/AccountantTemplate";
import { ModernTemplate } from "./templates/ModernTemplate";
import { DefaultTemplate } from "./templates/DefaultTemplate";

interface CVPreviewProps {
  cvData: CVData;
  templateId: string;
}

export function CVPreview({ cvData, templateId }: CVPreviewProps) {
  const renderTemplate = () => {
    switch (templateId) {
      case "accountant":
      case "office-manager":
      case "executive":
        return <AccountantTemplate cvData={cvData} />;
      case "hr-generalist":
      case "creative":
        return <ModernTemplate cvData={cvData} />;
      default:
        return <DefaultTemplate cvData={cvData} />;
    }
  };

  return <div data-testid="cv-preview">{renderTemplate()}</div>;
}
