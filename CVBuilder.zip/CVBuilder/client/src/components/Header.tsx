import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, Moon, Sun } from "lucide-react";
import { useState, useEffect } from "react";

export function Header() {
  const [, setLocation] = useLocation();
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "light" | "dark" | null;
    const initialTheme = savedTheme || "light";
    setTheme(initialTheme);
    document.documentElement.classList.toggle("dark", initialTheme === "dark");
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    document.documentElement.classList.toggle("dark", newTheme === "dark");
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-lg border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="flex items-center gap-3 hover-elevate active-elevate-2 rounded-lg px-3 py-2 -ml-3" data-testid="link-home">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary text-primary-foreground">
              <FileText className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-tight">Qera's Smart Assistant</span>
              <span className="text-xs text-muted-foreground hidden sm:block">Build Your Perfect CV</span>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
              className="rounded-full"
            >
              {theme === "light" ? (
                <Moon className="w-5 h-5" />
              ) : (
                <Sun className="w-5 h-5" />
              )}
            </Button>
            <Button
              onClick={() => setLocation("/builder")}
              className="hidden sm:flex"
              data-testid="button-create-cv"
            >
              Create Your CV
            </Button>
            <Button
              size="icon"
              onClick={() => setLocation("/builder")}
              className="sm:hidden"
              data-testid="button-create-cv-mobile"
            >
              <FileText className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
