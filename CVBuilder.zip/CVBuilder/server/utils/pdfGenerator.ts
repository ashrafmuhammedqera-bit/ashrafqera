import { jsPDF } from "jspdf";
import type { CVData } from "@shared/schema";

export async function generatePDF(cvData: CVData, templateId: string): Promise<Buffer> {
  const doc = new jsPDF();
  const { personalInfo, summary, experience, education, skills, references, activities } = cvData;
  
  let yPos = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);

  const isModern = templateId === "hr-generalist" || templateId === "creative";
  const isAccountant = templateId === "accountant" || templateId === "office-manager" || templateId === "executive";

  if (isModern) {
    doc.setFillColor(37, 99, 235);
    doc.rect(0, 0, pageWidth, 50, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(28);
    doc.setFont("helvetica", "bold");
    doc.text(personalInfo.fullName, margin, 25);
    
    doc.setFontSize(16);
    doc.setFont("helvetica", "normal");
    doc.text(personalInfo.title, margin, 35);
    
    doc.setFontSize(9);
    const contactModern = [personalInfo.email, personalInfo.phone].filter(Boolean).join(" | ");
    doc.text(contactModern, margin, 43);
    
    doc.setTextColor(0, 0, 0);
    yPos = 60;
  } else if (isAccountant) {
    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text(personalInfo.fullName, pageWidth / 2, yPos, { align: "center" });
    yPos += 8;

    doc.setFontSize(14);
    doc.setFont("helvetica", "normal");
    doc.text(personalInfo.title, pageWidth / 2, yPos, { align: "center" });
    yPos += 10;

    doc.setFontSize(10);
    const contactInfo = [personalInfo.phone, personalInfo.email, personalInfo.website].filter(Boolean).join(" | ");
    doc.text(contactInfo, pageWidth / 2, yPos, { align: "center" });
    yPos += 12;

    doc.setLineWidth(0.5);
    doc.line(margin, yPos, pageWidth - margin, yPos);
    yPos += 10;
  } else {

    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text(personalInfo.fullName, pageWidth / 2, yPos, { align: "center" });
    yPos += 8;

    doc.setFontSize(14);
    doc.setFont("helvetica", "normal");
    doc.text(personalInfo.title, pageWidth / 2, yPos, { align: "center" });
    yPos += 10;

    doc.setFontSize(10);
    const contactInfo = [
      personalInfo.email,
      personalInfo.phone,
      personalInfo.website,
      personalInfo.address
    ].filter(Boolean).join(" | ");
    doc.text(contactInfo, pageWidth / 2, yPos, { align: "center" });
    yPos += 12;

    doc.setLineWidth(0.5);
    doc.line(margin, yPos, pageWidth - margin, yPos);
    yPos += 10;
  }

  if (summary) {
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    if (isModern) {
      doc.setTextColor(37, 99, 235);
    }
    const summaryTitle = isAccountant ? "BACKGROUND" : "SUMMARY";
    doc.text(summaryTitle, margin, yPos);
    doc.setTextColor(0, 0, 0);
    yPos += 6;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const summaryLines = doc.splitTextToSize(summary, contentWidth);
    doc.text(summaryLines, margin, yPos);
    yPos += summaryLines.length * 5 + 8;
  }

  if (experience && experience.length > 0) {
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("EXPERIENCE", margin, yPos);
    yPos += 6;

    experience.forEach((exp) => {
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text(exp.title, margin, yPos);
      yPos += 5;

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const companyText = `${exp.company}${exp.location ? ` | ${exp.location}` : ""}`;
      doc.text(companyText, margin, yPos);
      
      const dateText = `${exp.startDate} - ${exp.current ? "Present" : exp.endDate || ""}`;
      doc.text(dateText, pageWidth - margin, yPos, { align: "right" });
      yPos += 5;

      if (exp.description) {
        const descLines = doc.splitTextToSize(exp.description, contentWidth);
        doc.text(descLines, margin, yPos);
        yPos += descLines.length * 5;
      }
      yPos += 6;
    });
  }

  if (education && education.length > 0) {
    if (yPos > 230) {
      doc.addPage();
      yPos = 20;
    }

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("EDUCATION", margin, yPos);
    yPos += 6;

    education.forEach((edu) => {
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text(edu.degree, margin, yPos);
      yPos += 5;

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const schoolText = `${edu.school}${edu.location ? ` | ${edu.location}` : ""}`;
      doc.text(schoolText, margin, yPos);
      
      if (edu.graduationDate) {
        doc.text(edu.graduationDate, pageWidth - margin, yPos, { align: "right" });
      }
      yPos += 5;

      if (edu.gpa) {
        doc.text(`GPA: ${edu.gpa}`, margin, yPos);
        yPos += 5;
      }

      if (edu.coursework) {
        const courseworkLines = doc.splitTextToSize(`Coursework: ${edu.coursework}`, contentWidth);
        doc.text(courseworkLines, margin, yPos);
        yPos += courseworkLines.length * 5;
      }
      yPos += 6;
    });
  }

  if (skills && skills.length > 0) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("SKILLS", margin, yPos);
    yPos += 6;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const skillsText = skills.join(" • ");
    const skillsLines = doc.splitTextToSize(skillsText, contentWidth);
    doc.text(skillsLines, margin, yPos);
    yPos += skillsLines.length * 5 + 8;
  }

  if (activities) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("ACTIVITIES & INTERESTS", margin, yPos);
    yPos += 6;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const activitiesLines = doc.splitTextToSize(activities, contentWidth);
    doc.text(activitiesLines, margin, yPos);
    yPos += activitiesLines.length * 5 + 8;
  }

  if (references) {
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("REFERENCES", margin, yPos);
    yPos += 6;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    const referencesLines = doc.splitTextToSize(references, contentWidth);
    doc.text(referencesLines, margin, yPos);
  }

  const pdfOutput = doc.output("arraybuffer");
  return Buffer.from(pdfOutput);
}
