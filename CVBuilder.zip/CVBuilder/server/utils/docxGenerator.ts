import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } from "docx";
import type { CVData } from "@shared/schema";

export async function generateDOCX(cvData: CVData, templateId: string): Promise<Buffer> {
  const { personalInfo, summary, experience, education, skills, references, activities } = cvData;

  const sections: Paragraph[] = [];
  
  const isModern = templateId === "hr-generalist" || templateId === "creative";
  const isAccountant = templateId === "accountant" || templateId === "office-manager" || templateId === "executive";

  sections.push(
    new Paragraph({
      text: personalInfo.fullName,
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
    })
  );

  sections.push(
    new Paragraph({
      text: personalInfo.title,
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
    })
  );

  const contactParts = [
    personalInfo.email,
    personalInfo.phone,
    personalInfo.website,
    personalInfo.address,
  ].filter(Boolean);

  sections.push(
    new Paragraph({
      text: contactParts.join(" | "),
      alignment: AlignmentType.CENTER,
      spacing: { after: 300 },
    })
  );

  if (summary) {
    const summaryTitle = isAccountant ? "BACKGROUND" : (isModern ? "PROFESSIONAL SUMMARY" : "SUMMARY");
    sections.push(
      new Paragraph({
        text: summaryTitle,
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: isModern ? "2563EB" : "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    sections.push(
      new Paragraph({
        text: summary,
        spacing: { after: 300 },
      })
    );
  }

  if (experience && experience.length > 0) {
    sections.push(
      new Paragraph({
        text: "EXPERIENCE",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    experience.forEach((exp) => {
      sections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: exp.title,
              bold: true,
              size: 22,
            }),
          ],
          spacing: { before: 100, after: 50 },
        })
      );

      const companyText = `${exp.company}${exp.location ? ` | ${exp.location}` : ""}`;
      const dateText = `${exp.startDate} - ${exp.current ? "Present" : exp.endDate || ""}`;

      sections.push(
        new Paragraph({
          text: companyText,
          spacing: { after: 50 },
        })
      );

      sections.push(
        new Paragraph({
          text: dateText,
          italics: true,
          spacing: { after: 100 },
        })
      );

      if (exp.description) {
        sections.push(
          new Paragraph({
            text: exp.description,
            spacing: { after: 200 },
          })
        );
      }
    });
  }

  if (education && education.length > 0) {
    sections.push(
      new Paragraph({
        text: "EDUCATION",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    education.forEach((edu) => {
      sections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: edu.degree,
              bold: true,
              size: 22,
            }),
          ],
          spacing: { before: 100, after: 50 },
        })
      );

      const schoolText = `${edu.school}${edu.location ? ` | ${edu.location}` : ""}`;
      sections.push(
        new Paragraph({
          text: schoolText,
          spacing: { after: 50 },
        })
      );

      if (edu.graduationDate) {
        sections.push(
          new Paragraph({
            text: edu.graduationDate,
            italics: true,
            spacing: { after: 50 },
          })
        );
      }

      if (edu.gpa) {
        sections.push(
          new Paragraph({
            text: `GPA: ${edu.gpa}`,
            spacing: { after: 50 },
          })
        );
      }

      if (edu.coursework) {
        sections.push(
          new Paragraph({
            text: `Coursework: ${edu.coursework}`,
            spacing: { after: 200 },
          })
        );
      }
    });
  }

  if (skills && skills.length > 0) {
    sections.push(
      new Paragraph({
        text: "SKILLS",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    sections.push(
      new Paragraph({
        text: skills.join(" • "),
        spacing: { after: 300 },
      })
    );
  }

  if (activities) {
    sections.push(
      new Paragraph({
        text: "ACTIVITIES & INTERESTS",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    sections.push(
      new Paragraph({
        text: activities,
        spacing: { after: 300 },
      })
    );
  }

  if (references) {
    sections.push(
      new Paragraph({
        text: "REFERENCES",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 200, after: 100 },
        border: {
          bottom: {
            color: "000000",
            space: 1,
            style: BorderStyle.SINGLE,
            size: 6,
          },
        },
      })
    );

    sections.push(
      new Paragraph({
        text: references,
        spacing: { after: 300 },
      })
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: sections,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return buffer;
}
