import { type CV, type InsertCV } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createCV(cv: InsertCV): Promise<CV>;
  getCV(id: string): Promise<CV | undefined>;
  getAllCVs(): Promise<CV[]>;
}

export class MemStorage implements IStorage {
  private cvs: Map<string, CV>;

  constructor() {
    this.cvs = new Map();
  }

  async createCV(insertCV: InsertCV): Promise<CV> {
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    const cv: CV = { ...insertCV, id, createdAt };
    this.cvs.set(id, cv);
    return cv;
  }

  async getCV(id: string): Promise<CV | undefined> {
    return this.cvs.get(id);
  }

  async getAllCVs(): Promise<CV[]> {
    return Array.from(this.cvs.values());
  }
}

export const storage = new MemStorage();
