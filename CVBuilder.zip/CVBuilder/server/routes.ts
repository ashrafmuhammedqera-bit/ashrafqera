import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCVSchema, cvDataSchema } from "@shared/schema";
import { generatePDF } from "./utils/pdfGenerator";
import { generateDOCX } from "./utils/docxGenerator";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/cvs", async (req, res) => {
    try {
      const validatedData = insertCVSchema.parse(req.body);
      const cv = await storage.createCV(validatedData);
      res.json(cv);
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Invalid CV data" });
    }
  });

  app.get("/api/cvs/:id", async (req, res) => {
    try {
      const cv = await storage.getCV(req.params.id);
      if (!cv) {
        return res.status(404).json({ error: "CV not found" });
      }
      res.json(cv);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to fetch CV" });
    }
  });

  app.post("/api/cvs/generate-pdf", async (req, res) => {
    try {
      const { cvData, templateId } = req.body;
      const validatedData = cvDataSchema.parse(cvData);
      
      const pdfBuffer = await generatePDF(validatedData, templateId);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=cv-${validatedData.personalInfo.fullName.replace(/\s+/g, '-')}.pdf`);
      res.send(pdfBuffer);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to generate PDF" });
    }
  });

  app.post("/api/cvs/generate-docx", async (req, res) => {
    try {
      const { cvData, templateId } = req.body;
      const validatedData = cvDataSchema.parse(cvData);
      
      const docxBuffer = await generateDOCX(validatedData, templateId);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      res.setHeader('Content-Disposition', `attachment; filename=cv-${validatedData.personalInfo.fullName.replace(/\s+/g, '-')}.docx`);
      res.send(docxBuffer);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to generate DOCX" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
